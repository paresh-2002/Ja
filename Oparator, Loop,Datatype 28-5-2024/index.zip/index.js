// Variable 
// var name = "Nilesh";
// var age = 20;
// age = 25;
// console.log(name +' is '+ age + ' Year old');


// let name = 'Rakesh';
// let age = 30;
// age = 35 // value can be re-assign
// let age = 35 // Variable name can't re-assign
// console.log(name +' is '+ age + ' Year old');

// const name = 'Ramesh';
// const age = 18;
// age = 25; // Variable and Value Can't Re-assign because this is a constant VAriable
// console.log(name +' is '+ age + ' Year old');

// JavaScript has 8 Datatypes

// String
// var name = "Nilesh";
// const name = 'Ramesh';
// console.log(name);
// console.log(typeof(name));

// Number
// integer Number
// let age = 30;
// console.log(age);
// Floating Number
// var float = 20.02;
// console.log(float);
// console.log(typeof(float));

// Bigint
// let x = BigInt('1234567891234567891234567890');
// console.log(x);
// console.log(typeof(x));

// Boolean
// Boolean DataType return true and false value
// let num = 30;
// let num1 = 30;
// console.log(num == num1);
// console.log(num >= num1);
// console.log(typeof(num == num1));


// Undefined
// variable without a value, has the value undefined
// let x;
// console.log(x); 
// console.log(typeof(x));

// Null

// Symbol


// Object
// JavaScript objects are written with curly braces {}
// Object properties are written as name:value pairs, separated by commas.


// const obj = {
//     fistName: 'John',
//     lastname:'Naresh',
//     age: 20,
//     city:'Surat',
//     fullname: function(){
//         return this.fistName +' '+ this.lastname;
//     },
// };
// console.log(obj.fullname());
// access object properties in two ways
// console.log(obj.age);
// console.log(obj['city']);
// console.log(typeof(obj));

// create a new JavaScript object using new Object()
// const obj1 = new Object();
// obj1.lastname = 'John';
// obj1.name='Sanjay';
// console.log(obj1);

// JavaScript Object Constructors
// function Animal(name,color,age){
// this.name = name;
// this.color = color;
// this.age = age;
// }
//  const cat = new Animal('cat','black',14);
//  console.log(cat);


// Operator

// Arithmetic Operators
// +,-,*,/,%
// let num = 2;
// let x = 100+100/num*5-10;
// console.log(x);

// Assignment Operators
// =,+=,-=,*=,/=,%=,**=

// Comparison Operators
// <,>,==,===,<=,>=,!=,!==,?

// Logical Operators
// ||,&&,!

// Ternary Operators
// let num = 54;
// let num1 = 25;
// let less = num<num1?true:false;
// console.log(less);

// Condition Statement
// let a = 10;
// let b = 25;
// if(a>b){
//     console.log('A is Grater then B');
// }else{
//     console.log('B is grader then A');
// }

// Loop Statement
// for loop
// for(i=1;i<=5;i++){
//     for(j=1;j<=i;j++){
//         console.log(i);
//     }
// }
// console.log();

// for in loop
// const animal = {name:'cat',color:'black',age:14}
// let text = ''
// for(let x in animal){
//     console.log( animal[x] + ' ');
// }

// forEach loop
// let arr = [1,2,5,6,4,10,2,5,1,0]

// arr.forEach(element => {
//     console.log(element);
// });

// for of loop
// let arr = [1,2,5,6,4]
// for(i of arr){
//     console.log(i);
// }

// while Loop
// let i = 0;
// while(i<10){
//     console.log(i);
//     i++;
// }

// do while loop
// let i = 0;
// do{
//     console.log('this is a DO while loop');
//     i++
// }while(i>10);

// break Statement

// for(i = 0; i<=10; i++){
//     if(i===4){
//         break;
//     }
//     console.log(i);
// }
// for(i = 0; i<=10; i++){
//     if(i===5){
//         continue;
//     }
//     console.log(i);
// }



// let student = [
//     {Name: 'John', marks:[10,40,50,60,50]},
//     {Name: 'deo', marks:[10,60,50,60,50]},
//     {Name: 'leo', marks:[10,20,80,60,50]},
// ]

// let x = ''
// for(let i in student){
//    x += '<h1>'+ student[i].Name + '</h1>';
//     for(let j in student[i].marks){
//         x += student[i].marks[j] +'<br>';
//     }
// }
// document.write(x)

