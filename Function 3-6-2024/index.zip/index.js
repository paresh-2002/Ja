// HTML DOM Elements
    // const para = document.getElementsByTagName('p');
    // const Class = document.getElementsByClassName('main');
    // const selector = document.querySelectorAll('p.main');
    // document.getElementById('demo').innerHTML = 'Hello, This is a DOM ' +  selector[0].innerHTML;

    // const form = document.forms['fox'];
    // let text = ''
    // for(let i = 0; i < form.length; i++) {
    //     text += form.elements[i].value + '<br>';
    // }
    // document.getElementById('demo').innerHTML = text;

    // document.getElementById('demo').innerHTML = 'How Many Anchor Tag ' + document.anchors.length;
    // document.getElementById('demo').innerHTML = document.body.innerHTML;
    // document.getElementById('demo').innerHTML = document.documentElement.innerHTML;
    // document.getElementById('demo').innerHTML = document.embeds.length;
    // document.getElementById('demo').innerHTML = document.links.length;
    // document.getElementById('demo').innerHTML = document.scripts.length;
    // document.getElementById('demo').innerHTML = document.title;

// HTML DOM - Changing HTML
    // The easiest way to modify the content of an HTML element is by using the innerHTML property.
        // document.getElementById('id01').innerHTML = 'New Heading'

    // To change the value of an HTML attribute,
        // document.getElementById('image').src = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRj0zm8fT8QhA0Ou03Q32XNUgXjkK82wHPi5Q&s'

        // document.getElementById('demo').innerHTML = 'Date:' + Date()

    // document.write() can be used to write directly to the HTML output stream:
        // document.write(Date());

// Forms
    // function validateForm() {
    //     let x = document.forms["myForm"]["fname"].value;
    //     if (x == "") {
    //         alert("Please enter your FirstName");
    //         return false;
    //     }
    // }
// document.getElementById('id01').style.color='pink'
// document.getElementById('id01').style.fontFamily='Helvetica'
// document.getElementById('id01').style.fontSize='40px'

// document.getElementById('demo').innerHTML = `
// <!-- <button type="button" onclick ="document.getElementById('id01').style.color = 'yellow'">Click</button> -->
// <button type="button" onclick ="document.getElementById('id01').style.visibility = 'hidden'">Text Hide</button>
// <button type="button" onclick ="document.getElementById('id01').style.visibility = 'visible'">Text Show</button>
// `